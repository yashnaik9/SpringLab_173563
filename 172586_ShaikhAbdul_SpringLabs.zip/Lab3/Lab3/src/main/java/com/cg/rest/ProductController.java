package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.NestedServletException;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Controller
public class ProductController {

	@Autowired
	private ProductRepo repo;
	
	@ExceptionHandler({java.sql.SQLIntegrityConstraintViolationException.class,
		NestedServletException.class,
		JpaSystemException.class,
		javax.persistence.PersistenceException.class,
		org.hibernate.exception.ConstraintViolationException.class
		})
		public ModelAndView error() {
		return new ModelAndView("Page Does not Exist!");
		}
	@RequestMapping("/")
	public String jump(Model m) {
		m.addAttribute("details", new Product());
		return "product";
	}
	
	@RequestMapping("/addproduct")
	public String addProduct(@ModelAttribute("details") Product product, Model m) {
		
		m.addAttribute("details", new Product());
		repo.saveProduct(product);
		return "productsuccess";

	}
	
}
