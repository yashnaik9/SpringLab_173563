package com.cg.repo;

import com.cg.entity.Product;

public interface ProductRepo {

	
	void saveProduct(Product product);

}
