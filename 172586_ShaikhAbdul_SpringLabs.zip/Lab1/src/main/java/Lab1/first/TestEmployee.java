package Lab1.first;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx=new ClassPathXmlApplicationContext("employee.xml");
		Employee empl=(Employee) ctx.getBean("emp");
		System.out.println("Employee Details");
		System.out.println("---------------------------");
		System.out.println(empl);
	}

}
