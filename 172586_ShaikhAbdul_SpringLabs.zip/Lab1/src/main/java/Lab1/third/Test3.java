package Lab1.third;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx=new ClassPathXmlApplicationContext("Lab1.3.xml");
//		Employee empl=(Employee) ctx.getBean("emp");
//		Employee empl2=(Employee) ctx.getBean("emp2");
		Sbu s=(Sbu) ctx.getBean("sbu");
//		s.setEmp(empl);
//		s.setEmp(empl2);
		System.out.println(s);
		
	}

}
