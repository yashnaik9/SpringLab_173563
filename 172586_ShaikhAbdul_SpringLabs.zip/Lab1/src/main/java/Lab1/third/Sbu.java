package Lab1.third;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component("sbu")
public class Sbu {

	@Id
	private String sbuId;
	private String sbuName;
	private String sbuHead;
	
	List<Employee> emp=new ArrayList<Employee>();
	
	public List<Employee> getEmp() {
		return emp;
	}


	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}


	public Sbu() {
		// TODO Auto-generated constructor stub
	}


	public String getSbuId() {
		return sbuId;
	}


	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}


	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}


	@Override
	public String toString() {
		return "Sbu [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", emp=" + emp + "]";
	}




	
	
}
