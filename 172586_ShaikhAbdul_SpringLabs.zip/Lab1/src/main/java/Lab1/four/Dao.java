package Lab1.four;

import java.util.HashMap;
import java.util.Map;

import Lab1.four.Employee;

public class Dao implements IDao {

	Map<Integer, Employee> map=new HashMap<Integer, Employee>();
	
	@Override
	public void add(int id,Employee emp) {
		// TODO Auto-generated method stub
		map.put(id, emp);
	}

	@Override
	public void display(int id) {
		// TODO Auto-generated method stub
		if (map.containsKey(id)) {
			System.out.println(map.get(id));
		}else {
			System.out.println("Id does not Exist!");
		}
	}

}
