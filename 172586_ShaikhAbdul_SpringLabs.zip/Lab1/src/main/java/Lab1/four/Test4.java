package Lab1.four;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Test4 {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("Lab1.4.xml");
		Scanner scx=new Scanner(System.in);
		IDao dao=ctx.getBean(Dao.class);
		Employee emp=(Employee) ctx.getBean("empbean");
		Employee emp2=(Employee) ctx.getBean("empbean2");
		dao.add(emp.getEmployeeId(), emp);
		dao.add(emp2.getEmployeeId(), emp2);
		System.out.println("Enter Id to be Searched:");
		int id=scx.nextInt();
		dao.display(id);
	}
	
}
