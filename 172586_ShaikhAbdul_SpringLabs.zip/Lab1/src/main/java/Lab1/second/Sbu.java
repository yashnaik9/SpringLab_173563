package Lab1.second;

import org.springframework.stereotype.Component;

@Component("sbu")
public class Sbu {

	private String sbuId;
	private String sbuName;
	private String sbuHead;
	
	public Sbu() {
		// TODO Auto-generated constructor stub
	}


	public String getSbuId() {
		return sbuId;
	}


	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}


	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}


	@Override
	public String toString() {
		return "Sbu [sbu Code=" + sbuId + ", sbu Name=" + sbuName + ", sbu Head=" + sbuHead + "]";
	}
	
	
	
}
