package com.cg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.validation.constraints.NotEmpty;

@Entity
public class TraineeDetails {

	@javax.persistence.Id
	@Column(length=4,name="Trainee_Id")
	private int Id;
	@Column(length=20,name="Trainee_Name")
	private String Name;
	@Column(length=10,name="Trainee_Location")
	private String Location;
	@Column(length=10,name="Trainee_Domain")
	private String Domain;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getDomain() {
		return Domain;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	@Override
	public String toString() {
		return "TraineeDetails [Id=" + Id + ", Name=" + Name + ", Location=" + Location + ", Domain=" + Domain + "]";
	}
	
	
}
