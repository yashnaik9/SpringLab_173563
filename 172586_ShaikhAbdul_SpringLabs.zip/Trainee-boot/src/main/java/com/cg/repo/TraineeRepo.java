package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.TraineeDetails;

public interface TraineeRepo extends CrudRepository<TraineeDetails, Integer> {

}
