package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.TraineeDetails;
import com.cg.repo.TraineeRepo;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	TraineeRepo repo;

	@Override
	public String saveTrainee(TraineeDetails t) {
		repo.save(t);
		return "Added Successfully";
	}

	@Override
	public TraineeDetails getTrainee(int Id) {
		
		return repo.findById(Id).get();
	}

	@Override
	public List<TraineeDetails> getAll() {
		List<TraineeDetails> list=(List<TraineeDetails>) repo.findAll();
		return list;
	}

	@Override
	public String deleteTrainee(TraineeDetails trainee) {
		repo.delete(trainee);
		return "Deleted Successfully";
	}

	@Override
	public String modifyTrainee(int Id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
