package com.cg.service;

import java.util.List;

import com.cg.TraineeDetails;

public interface ITraineeService {

	public String saveTrainee(TraineeDetails t);
	public TraineeDetails getTrainee(int Id);
	public List<TraineeDetails> getAll();
	public String deleteTrainee(TraineeDetails trainee);
	public String modifyTrainee(int Id);
}
