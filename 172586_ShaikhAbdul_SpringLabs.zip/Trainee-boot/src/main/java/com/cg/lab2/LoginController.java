package com.cg.lab2;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.Login;
import com.cg.TraineeDetails;
import com.cg.service.ITraineeService;

@Controller
public class LoginController {
	
	@Autowired
	ITraineeService service;
	TraineeDetails trainee;
	List<String> Location;
	List<String> Domain;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model m) {
		m.addAttribute("login", new Login());
		
		return "Login";
	}
	

	@RequestMapping(path="/login")
	public String test(@ModelAttribute("login")
	@Valid Login login,BindingResult result,
	Model model)
	{
//		if (result.hasErrors()) {
//			 System.out.println("Error");
//			 return "Login";
//		} else {
//			 model.addAttribute("login",login);  
//	          System.out.println("Valid login credentials ");
//		  	  return "Trainee";	
//		}
		return "Trainee";	
	}
	
	@RequestMapping(path="/create")
	public String add(Model m) {
		Location=new ArrayList<>();
		Location.add("Chennai");
		Location.add("Bangalore");
		Location.add("pune");
		Location.add("Mumbai");
		
		Domain=new ArrayList<>();
		Domain.add("Java");
		Domain.add("IoT");
		Domain.add("SAP");
		Domain.add("Cloud");
		
		m.addAttribute("Location", Location);
		m.addAttribute("Domain", Domain);
		m.addAttribute("trainee", new TraineeDetails());
		return "Add";
	}
	
	@RequestMapping(path="/saveTrainee")
	public String insertData(@ModelAttribute("trainee") TraineeDetails trainee,Model m) {
		System.out.println(service.saveTrainee(trainee));
		return "Trainee";
	}
	
	@RequestMapping(path="/find")
	public String get(@RequestParam("Id") int Id,Model m) {
		 trainee= service.getTrainee(Id); 
		System.out.println(trainee);
		m.addAttribute("trainee",trainee);
		return "Retrieve";
	}
	
	@RequestMapping(path="/Retrieve")
	public String get(Model m) {
		//m.addAttribute("trainee", new TraineeDetails());
		return "Retrieve";
	}
	@RequestMapping(path="/getAll")
	public String getAll(Model m) {
		//m.addAttribute("trainee", new TraineeDetails());
		List<TraineeDetails> traineelist=service.getAll();
		m.addAttribute("traineelist", traineelist);
		return "GetAll";
	}
	
	@RequestMapping(path="/goBack")
	public String goBack(Model m) {
		//m.addAttribute("trainee", new TraineeDetails());
		return "Trainee";
	}
	
	@RequestMapping(path="/Delete")
	public String goDelete(Model m) {
		//m.addAttribute("trainee", new TraineeDetails());
		return "Delete";
	}
	@RequestMapping(path="/delete")
	public String getDelete(@RequestParam("Id") int Id,Model m) {
		 trainee= service.getTrainee(Id); 
		System.out.println(trainee);
		m.addAttribute("trainee",trainee);
		return "Delete";
	}
	
	@RequestMapping(path="/deleteTrainee")
	public String deleted(Model m,TraineeDetails trainee) {
		service.deleteTrainee(trainee);
		//m.addAttribute("trainee", trainee);
		return "Trainee";
	}
	
	@RequestMapping(path="/Modify")
	public String goModify(Model m) {
		Location=new ArrayList<>();
		Location.add("Chennai");
		Location.add("Bangalore");
		Location.add("pune");
		Location.add("Mumbai");
		
		Domain=new ArrayList<>();
		Domain.add("Java");
		Domain.add("IoT");
		Domain.add("SAP");
		Domain.add("Cloud");
		
		m.addAttribute("Location", Location);
		m.addAttribute("Domain", Domain);
		m.addAttribute("trainee", new TraineeDetails());
		return "Modify";
	}
	
	@RequestMapping("/findModify")
	public String getModify(@RequestParam("id") int id,Model m) {
		 trainee= service.getTrainee(id); 
		System.out.println(trainee);
		m.addAttribute("trainee",trainee);
		m.addAttribute("Location", Location);
		m.addAttribute("Domain", Domain);	
		return "Modify";
		}
	
	@RequestMapping("/modify")
	public String Modify(@ModelAttribute("trainee") TraineeDetails trainee,Model m) {
		service.saveTrainee(trainee);
		System.out.println(trainee);
		System.out.println("Data Modified Successfully");
		m.addAttribute("Location", Location);
		m.addAttribute("Domain", Domain);	
		m.addAttribute("trainee",trainee);
		return "Trainee";
		}
	
}
