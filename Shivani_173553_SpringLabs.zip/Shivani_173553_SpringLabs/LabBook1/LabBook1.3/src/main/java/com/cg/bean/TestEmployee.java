package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestEmployee {

	public static void main(String[] args) {
		
		ApplicationContext ctx =new ClassPathXmlApplicationContext("employee.xml");
		SBU sbu = (SBU) ctx.getBean("sbuBean");
//		Employee emp = (Employee) ctx.getBean("employeeBean");
		
		System.out.println("SBU Details");
		System.out.println("------------------------");
		System.out.println(sbu);
		System.out.print("Employee details:");
		System.out.println("------------------------");
		System.out.println(sbu.getEmpList());
	}
}
