package com.cg.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		
		Scanner scan= new Scanner(System.in);
		System.out.print("Enter Employee id : ");
		int id = scan.nextInt();
		List<Employee> employees= new ArrayList<Employee>();
		ApplicationContext ctx =new ClassPathXmlApplicationContext("employee.xml");
		Employee emp1= (Employee) ctx.getBean("employeeBean");
		Employee emp2= (Employee) ctx.getBean("empBean");
		employees.add(emp1);
		employees.add(emp2);
		
		for(Employee e : employees) {
			if(e.getEmpId()==id)
				System.out.println(e);
		}
	}
}
