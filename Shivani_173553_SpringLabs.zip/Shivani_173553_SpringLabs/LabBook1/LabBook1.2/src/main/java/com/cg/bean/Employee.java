package com.cg.bean;

public class Employee {
	
	private int employeeId;
	private String employeeName;
	private double salary;
	private String empBU;
	SBU sbu = new SBU();
	
	public Employee() {
	}

	public Employee(int employeeId, String employeeName, double salary, String empBU, SBU sbu) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.empBU = empBU;
		this.sbu = sbu;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public SBU getSbu() {
		return sbu;
	}

	public void setSbu(SBU sbu) {
		this.sbu = sbu;
	}

	public String getEmpBU() {
		return empBU;
	}

	public void setEmpBU(String empBU) {
		this.empBU = empBU;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
				+ ", empBU=" + empBU + ", sbu=" + sbu + "]";
	}
	
}


