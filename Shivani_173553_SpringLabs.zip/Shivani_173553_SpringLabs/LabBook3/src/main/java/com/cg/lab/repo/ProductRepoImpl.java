package com.cg.lab.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lab.entity.Product;

@Repository
@Transactional
public class ProductRepoImpl implements IProductRepo {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	public void addProduct(Product product) {
		em.persist(product);
	}
}