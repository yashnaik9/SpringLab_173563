package com.cg.lab.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.NestedServletException;

import com.cg.lab.entity.Product;
import com.cg.lab.repo.IProductRepo;

@Controller
public class ProductController {

	@Autowired
	private IProductRepo repo;

	@GetMapping("/addProduct")
	public String sayHello(Model model) {
		model.addAttribute("productDetails", new Product());
		return "product";
	}

	@RequestMapping("addProduct")
	public String addProduct(@ModelAttribute("productDetails") Product product, Model model) {
		model.addAttribute("productDetails", new Product());

		repo.addProduct(product);

		return "productAdded";

	}

	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class, NestedServletException.class,
			JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })
	public ModelAndView error() {
		return new ModelAndView("Error in the page...");
	}

}
