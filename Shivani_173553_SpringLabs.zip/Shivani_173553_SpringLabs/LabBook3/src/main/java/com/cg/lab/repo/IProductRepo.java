package com.cg.lab.repo;

import com.cg.lab.entity.Product;

public interface IProductRepo {

	void addProduct(Product product);

}
