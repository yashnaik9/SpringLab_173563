package com.cg.lab.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.lab.entity.Trainee;

public interface ITraineeDao extends CrudRepository<Trainee, Integer> {

}
