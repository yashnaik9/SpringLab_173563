package com.cg.lab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.lab.entity.Login;
import com.cg.lab.entity.Trainee;
import com.cg.lab.service.TraineeServiceImpl;

@Controller
public class TraineeController {

	@Autowired
	TraineeServiceImpl service;

	Trainee trainee;

	@RequestMapping("/")
	public String login(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "/checkLogin")
	public String checkLogin(Login login) {
		if (login.getUserName().equalsIgnoreCase("shivani") && login.getPassword().equalsIgnoreCase("qwerty"))
			return "loginSuccess";
		else {
			return "login";
		}
	}

	@RequestMapping(value = "/add")
	public String addTrainee(Model model) {
		model.addAttribute("addTrainee", new Trainee());
		return "addTrainee";
	}

	@RequestMapping("/addDataBase")
	public String addTrainee(@ModelAttribute("") Trainee addnew, Model model) {
		service.saveTrainee(addnew);
		return "loginSuccess";
	}

	@RequestMapping(value = "/delete")
	public String deletepage(Model model) {
		return "delete";
	}

	@RequestMapping("/search")
	public String retrieveTodelete(Model model, @RequestParam("traineeId") int traineeId) {
		trainee = service.getTrainee(traineeId);
		model.addAttribute(trainee);
		return "delete";
	}

	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model) {
		model.addAttribute(trainee);
		service.deleteTrainee(trainee);
		return "loginSuccess";
	}

	@RequestMapping(value = "/retrieve")
	public String retrieveDetails(Model model) {
		return "retrieve";
	}

	@RequestMapping("/retieveSingle")
	public String retrieveSingle(Model model, @RequestParam("traineeId") int traineeId) {
		trainee = service.getTrainee(traineeId);
		model.addAttribute(trainee);
		return "retrieve";
	}

	@RequestMapping("/menu")
	public String retrieveTrainee(Model model, Trainee trainee) {
		service.deleteTrainee(trainee);
		return "loginSuccess";
	}

	@RequestMapping(value = "/allTrainees")
	public String retrieveAllTrainee(Model model) {
		Iterable<Trainee> allTrainee = service.getAll();
		model.addAttribute("allTrainee", allTrainee);
		return "retrieveAll";

	}

	@RequestMapping("/goToMenu")
	public String gotomenu(Model model) {
		return "loginSuccess";
	}

}
