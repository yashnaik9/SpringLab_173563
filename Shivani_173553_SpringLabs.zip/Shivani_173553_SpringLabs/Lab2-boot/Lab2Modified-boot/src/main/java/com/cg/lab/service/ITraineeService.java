package com.cg.lab.service;

import com.cg.lab.entity.Trainee;

public interface ITraineeService {

	void saveTrainee(Trainee t);

	Trainee getTrainee(int id);

	Iterable<Trainee> getAll();

	public String deleteTrainee(Trainee t1);

	public Trainee updateTrainee(Trainee t, int id);

}
