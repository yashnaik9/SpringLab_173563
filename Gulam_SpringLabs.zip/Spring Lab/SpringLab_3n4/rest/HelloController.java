package com.cg.rest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.Product;
import com.cg.repo.ProductRepo;

@RestController
public class HelloController {
	@Autowired
	ProductRepo repo;
	
//	@GetMapping("/hola/{name}")
//	public String sayHello(@PathVariable("name") String name) {
//		return "Hello "+name+", Welcome to spring Boot";
//	}
//	@GetMapping("/bye")
//	@ResponseBody
//	public String sayGoodbye(@RequestParam("name") String name) {
//		return "Bye " +name+",Visit again!";
//	}
//	
	@PostMapping("/add")
	public String saveProduct(@RequestParam("name") String name, @RequestParam("price") double price) {
		Product p = new Product();
		p.setName(name);
		p.setPrice(price);
		repo.saveProduct(p);
		
		return "Product Saved";
	}
	
	@GetMapping(name="/product" , produces="application/json")
	public Product getProduct(@RequestParam("id")int id) {
	Product p = repo.get(id);
	return p;
	}
	
}
