package com.cg.ioc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeClient {
	
	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		//Employee employee = (Employee) ctx.getBean("emp");
		SBU sbu = (SBU) ctx.getBean("sbu");
		
		System.out.println("SBU details\n---------------------");
		System.out.println(sbu);
		System.out.println("Employee Details\n---------------------");
		System.out.println(sbu.getEmployee());
	}

}
