package com.cg.rest;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	ITraineeService service;
	ArrayList<String> locationList;
	ArrayList<String> domain;
	Trainee trn;

	@RequestMapping("/")
	public String startLogin(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login login, BindingResult result, Model model) {
		if (login.getUserName().equals("gulam") && login.getPassword().equals("12345"))
			return "home";
		else {
			model.addAttribute("lnvalid", "Invalid Login details");

			return "login";
		}
	}

	@RequestMapping("/addTrainee")
	public String addTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		locationList = new ArrayList<String>();
		domain = new ArrayList<String>();

		locationList.add("Mumbai");
		locationList.add("Delhi");
		locationList.add("Bangalore");
		locationList.add("Chennai");

		domain.add("Java");
		domain.add("Python");
		domain.add("Hibernate");
		domain.add("Struts");
		domain.add("Spring");
		

		model.addAttribute("locationList", locationList);
		model.addAttribute("domain", domain);
		return "addTrainee";

	}
	@RequestMapping("added")
	public String addTrainee(@ModelAttribute("trainee") @Valid Trainee trn, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("error", "Plese provide Valid trainee data");
			model.addAttribute("locationList", locationList);
			model.addAttribute("domain", domain);
			return "addTrainee";
		} else {
			service.addTrainee(trn);
			model.addAttribute("result", "Trainee Added Successfully.!!");
			return "home";
		}
	}

	
	@RequestMapping("/delete")
	public String deleteTrainee(Model model) {
		model.addAttribute("trainee", null);
		return "traineedelete";
	}
	
	@RequestMapping("traineefordelete")
	public String getTrnForDel(int id, Model model) {
		trn = service.getById(id);
		System.out.println(trn);
		model.addAttribute("trainee", trn);
		return "traineedelete";

	}
	
	@RequestMapping("deletetrainee")
	public String deleteTraine(Model model) {
		System.out.println(trn);
		if (trn != null) {
			service.deleteTrainee(trn);
			trn = null;
			model.addAttribute("delresult", "Trainee deleted");
			return "home";
		} else {
			model.addAttribute("error", "Provide valid Trainee Id");
			return "traineedelete";
		}
	}
	
	@RequestMapping("/modify")
	public String modify(Model model) {
		locationList = new ArrayList<String>();
		domain = new ArrayList<String>();

		locationList.add("Mumbai");
		locationList.add("Delhi");
		locationList.add("Bangalore");
		locationList.add("Chennai");

		domain.add("Java");
		domain.add("Python");
		domain.add("Hibernate");
		domain.add("Struts");
		domain.add("Spring");
		
		model.addAttribute("trainee", new Trainee());
		model.addAttribute("locationList", locationList);
		model.addAttribute("domain", domain);
		
		return "modifytrainee";
		
	}
	
	@RequestMapping("traineeformodify")
	public String getTraineeForMod(int id, Model model) {
		trn = service.getById(id);
		System.out.println(trn);
		model.addAttribute("trainee", trn);
		model.addAttribute("locationList", locationList);
		model.addAttribute("domain", domain);
		return "modifytrainee";
	}
	
	@RequestMapping("modifiedetrainee")
	public String modifyTrainee(@ModelAttribute("trainee") Trainee trn, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("error", "Plese provide Valid trainee data");
			model.addAttribute("locationList", locationList);
			model.addAttribute("domain", domain);
			return "modifytrainee";
		} else {
			service.addTrainee(trn);
			model.addAttribute("operation", "Employee modify Successfully");
			return "home";
		}
	}
	
	@RequestMapping("/getTrainee")
	public String gtTrainee(Model model) {
		model.addAttribute("trainee", null);
		return "retrievetrainee";
	}

	@RequestMapping("gettrainee")
	public String getTrainee(int id, Model model) {
		Trainee trn = service.getById(id);
		System.out.println(trn);
		model.addAttribute("trainee", trn);
		return "retrievetrainee";

	}
	@RequestMapping("/allTrainee")
	public String retrieveAll(Model model) {
		Iterable<Trainee> iterable = service.findAll();
		List<Trainee> list = new ArrayList<>();
		iterable.forEach(list::add);
		for (Trainee trainee : list) {
			System.out.println(trainee);
		}
		model.addAttribute("listOfTrainee", list);
		return "retrieveall";
	}
	
	
	
	
	

	
}
