package com.cg.service;

import com.cg.entity.Trainee;

public interface ITraineeService {
	
	Trainee addTrainee(Trainee trainee);

	Trainee getById(int id);

	void deleteTrainee(Trainee trn);

	Iterable<Trainee> findAll();

}
