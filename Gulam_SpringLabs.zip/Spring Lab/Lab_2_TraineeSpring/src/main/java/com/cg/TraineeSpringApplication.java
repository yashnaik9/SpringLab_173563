package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraineeSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraineeSpringApplication.class, args);
	}

}
