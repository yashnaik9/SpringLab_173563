package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
import com.cg.repo.ITraineeRepo;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	ITraineeRepo repo;
	
	public Trainee addTrainee(Trainee trainee) {
		return repo.save(trainee);
	}
	
	@Override
	public Trainee getById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public void deleteTrainee(Trainee trn)  {
			repo.delete(trn);

	}

	@Override
	public Iterable<Trainee> findAll() {
		// return all Trainees from database
		return repo.findAll();
	}
	

}
