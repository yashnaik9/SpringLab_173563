package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entity.Trainee;

public interface ITraineeRepo extends JpaRepository<Trainee, Integer>{

}
