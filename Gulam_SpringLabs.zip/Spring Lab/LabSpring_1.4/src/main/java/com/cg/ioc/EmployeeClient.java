package com.cg.ioc;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeClient {
	
	public static void main(String[] args) {
		Scanner sc  = new Scanner(System.in);
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		SBU sbu = (SBU) ctx.getBean("sbu");
		
		
		System.out.println("Enter Employee ID");
		int id = sc.nextInt();
		System.out.println(sbu.findEmployee(id));
		
		
		
		
	
		
		
		
	}

}
