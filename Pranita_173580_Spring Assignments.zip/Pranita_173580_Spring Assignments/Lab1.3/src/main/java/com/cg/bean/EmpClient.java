package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpClient {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("details.xml");
		SBU sb = (SBU) ctx.getBean("sbu");
	//	Employee emp = (Employee) ctx.getBean("employee");
		
		System.out.println("SBU Details");
		System.out.println("---------------------");
		System.out.println(sb);
		System.out.println("Employee Details");
		System.out.println("-------------------------");
		System.out.println(sb.getEmpList());
	}
}