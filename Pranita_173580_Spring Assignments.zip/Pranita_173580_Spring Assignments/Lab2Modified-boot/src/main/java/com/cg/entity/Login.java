package com.cg.entity;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

public class Login {
	
	@NotEmpty(message=" UserName is mandatory")
	@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	private String userName;
	
	@NotEmpty(message=" Password is mandatory")
	@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
