package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class DaoImpl implements DaoI{

	List<Employee> list = new ArrayList<Employee>();
	ApplicationContext ctx = new ClassPathXmlApplicationContext("details.xml");
	Employee emp1= (Employee) ctx.getBean("emp1");
	Employee emp2= (Employee) ctx.getBean("emp2");
	
	@Override
	public void addAll() {
		list.add(emp1);
		list.add(emp2);
		
	}
	@Override
	public Employee findEmployee(int id) {
		for(Employee e : list) {
			if(e.getEmpId()==id)
				return e;
			else 
				return null;
		}
		return null;
	}	
	
}
