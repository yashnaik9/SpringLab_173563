package com.cg.bean;

public class Employee {

	private String empId;
	private String Name;
	private String Salary;
	private String BU;
	private String age;

	public Employee() {
	}

	public Employee(String empId, String name, String salary, String bU, String age) {
		this.empId = empId;
		Name = name;
		Salary = salary;
		BU = bU;
		this.age = age;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getSalary() {
		return Salary;
	}

	public void setSalary(String salary) {
		Salary = salary;
	}

	public String getBU() {
		return BU;
	}

	public void setBU(String bU) {
		BU = bU;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}
	
	
	
}
