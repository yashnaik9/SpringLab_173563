package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;

@Repository
@Transactional
public class ProductImpl implements ProductRepo {

	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	public void saveProduct(Product product) {
		em.persist(product);
	}

	
}
