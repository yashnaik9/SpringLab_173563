package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.NestedServletException;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Controller
public class ProductController {

	@Autowired
	private ProductRepo repo;
	
	
	@GetMapping("/addproduct")
	public String sayHello(Model model) {
		model.addAttribute("productdetails", new Product());
		return "product";
	}
	
	@RequestMapping("addproduct")
	public String addProduct(@ModelAttribute("productdetails") Product prod, Model model) {
		model.addAttribute("productdetails", new Product());
		
		repo.saveProduct(prod);

		return "productaddedSuccess";

	}
	

	@ExceptionHandler({java.sql.SQLIntegrityConstraintViolationException.class,
		NestedServletException.class,
		JpaSystemException.class,
		javax.persistence.PersistenceException.class,
		org.hibernate.exception.ConstraintViolationException.class
		})
		public ModelAndView error() {
		return new ModelAndView("Page is not displayed");
		}

}
