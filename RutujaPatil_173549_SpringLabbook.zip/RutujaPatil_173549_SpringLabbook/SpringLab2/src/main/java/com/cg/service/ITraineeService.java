package com.cg.service;

import com.cg.entity.Trainee;

public interface ITraineeService {
	void createTrainee(Trainee trainee);
	Trainee retriveTrainee(int traineeId);
	//Trainee udateTrainee(Trainee trainee,int traineeId);
	
	Iterable<Trainee> viewtraineeList();
	String deleteTrainee(int traineeId);
	Trainee udateTrainee(Trainee updateTrainee);
	

}
