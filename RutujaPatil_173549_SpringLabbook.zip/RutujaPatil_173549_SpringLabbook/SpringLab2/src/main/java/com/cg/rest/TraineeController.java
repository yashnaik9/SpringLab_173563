package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.ITraineeService;
import com.cg.service.TraineeServiceImpl;

@Controller
public class TraineeController {
	@Autowired
	TraineeServiceImpl service;
	
//login page will be displayed first
	@RequestMapping("/")
	public String login(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}
     //to navigate to add trainee page
	@RequestMapping("/add")
	public String addTrainee(Model model) {
		model.addAttribute("addtrainee", new Trainee());
		return "addtrainee";

	}
	// Logic to validate userName and password against database

	@RequestMapping(value = "checkLogin")
	public String checkLogin(Login login) {
		if (login.getUserName().equalsIgnoreCase("rutuja") && login.getPassword().equalsIgnoreCase("patil")) {
			return "loginSuccess";
		}
		
		else {
			return "login";
		}
	}
//to create new trainee and send back to loginSuccess page automatically where all the links are given 
	@RequestMapping("/createtrainee")
	public String createTrainee(@ModelAttribute("") Trainee addnewTrainee, Model model) {
		service.createTrainee(addnewTrainee);
		return "loginSuccess";

	}
	
//to navigate to delete page
	@RequestMapping("/delete")
	public String delete(Model model) {
		model.addAttribute("deletetTrainee");
		return "deletetrainee";

	}
	
//find a trainee by giving Id 
	@RequestMapping("/find")
	public String findTrainee(Model model, int traineeId) {
	trainee = service.retriveTrainee(traineeId);
		System.out.println(trainee);
		model.addAttribute("deleteTrainee", trainee);

		return "deletetrainee";

	}
	

	Trainee trainee;
//method to delete trainee
	@RequestMapping("deleteTrainee")
	public String deleteTrainee(Model model) {
		service.deleteTrainee(trainee.getTraineeId());
		return "loginSuccess";

	}
	
//method to navigate to retrive page
	@RequestMapping("/retrieve")
	public String getTrainee(Model model) {
		model.addAttribute("findTrainee");
		return "retrievetrainee";

	}
	@RequestMapping("/findTrainee")
	public String getTrainee(Model model, int traineeId) {
		trainee = service.retriveTrainee(traineeId);
	
		model.addAttribute("searchTrainee", trainee);

		return "retrievetrainee";

	}
	@RequestMapping("/searchTraineeDetails")
	public String findDetails(Model model) {
		
		return "loginSuccess";

	}
	//method to navigate to retriveall page
	@RequestMapping("/retrieveall")
	public String getAllTraineeDetails(Model model) {
	 Iterable<Trainee> traineeList = service.viewtraineeList();
	 model.addAttribute("traineeList", traineeList);
	 model.addAttribute("searchAllTrainee");
	 return "retrievealltrainees";
	}
//method to search all trainees data
	@RequestMapping("searchAllTraineeDetails")
	public String searchAllTraineeDetails(Model model) {
	 return "loginSuccess";
	}
	//method to navigate to modify page
	@RequestMapping("/modify")
	public String modifyTrainee(Model model, int traineeId) {
	 trainee = service.retriveTrainee(traineeId);
	
	 model.addAttribute("updateTrainee", trainee);
	 return "modifytrainee";
	}
	
	@RequestMapping("updateTrainee")
	public String updateTraineeDetails(@ModelAttribute("updateTrainee") Trainee updateTrainee, Model model) {
	 service.udateTrainee(updateTrainee);
	 return "loginSuccess";
	}
	
	@RequestMapping("update")
	public String update(Model model) {
	 model.addAttribute("updateTrainee", new Trainee());
	 return "updateDetails";
	}

	
	
	
	
	
	
	
	
	
	
	
	

}
