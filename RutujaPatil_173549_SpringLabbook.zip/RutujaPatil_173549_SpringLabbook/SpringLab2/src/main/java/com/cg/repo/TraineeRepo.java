package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cg.entity.Trainee;

/**
 * Repo interface which is implementing all the CRUD operations
 * @author rutujapa
 *
 */
public interface TraineeRepo extends JpaRepository<Trainee, Integer> {

}
