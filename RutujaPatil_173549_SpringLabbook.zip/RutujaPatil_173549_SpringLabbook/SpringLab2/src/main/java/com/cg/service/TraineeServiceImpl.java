package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;
/**
 * This is service class in which all the logic written
 * @author rutujapa
 *
 */
@Repository
@Transactional
public class TraineeServiceImpl implements ITraineeService {
	//Autowired is used to use repo class object
	@Autowired
	private TraineeRepo repo;

	@Override
	public void createTrainee(Trainee trainee) {
		 repo.save(trainee);
	
	}

	@Override
	public Trainee retriveTrainee(int traineeId) {
		return repo.findById(traineeId).get();
	}

	

	@Override
	public String deleteTrainee(int traineeId) {
		Trainee t=repo.findById(traineeId).get();
		repo.delete(t);
		return "Record deleted for given id";
	}

	@Override
	public Iterable<Trainee> viewtraineeList() {
		return repo.findAll();
	}

	
	@Override
	public Trainee udateTrainee(Trainee updateTrainee) {
		repo.save(updateTrainee);
		return updateTrainee;
	}

}
