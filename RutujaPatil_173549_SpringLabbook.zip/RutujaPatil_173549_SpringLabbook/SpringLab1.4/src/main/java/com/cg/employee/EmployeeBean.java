package com.cg.employee;

public class EmployeeBean {

	
	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	
	
	
	public EmployeeBean(int employeeId, String employeeName, double employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}
	

}
