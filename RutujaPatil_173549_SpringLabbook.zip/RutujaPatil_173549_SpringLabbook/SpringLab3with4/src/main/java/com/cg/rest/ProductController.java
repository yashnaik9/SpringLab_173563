package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
@RequestMapping("api/v1")
public class ProductController {

	@Autowired
	private ProductRepo repo;

	
	
	// This method is used to send to product page
	@GetMapping("/")
	public ModelAndView mainPage(Model model) {
		return new ModelAndView("product", "product", new Product());

	}


	// this method is to add a product into the record
	@PostMapping("/addproduct")
	public Product addProduct(@ModelAttribute("product") Product product, Model model) {
		product = repo.createProduct(product);
		model.addAttribute("addreport", "Product is added in the record");
		return product;

	}

	
	// this method is to vies all the products from the record
	@GetMapping(path = "/allproducts", produces = "application/json")
	public List<Product> viewAllProducts() {
		return repo.getAllProducts();
	}

	// exception handling for lab-4
	
	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })

	public ModelAndView showError(Model model) {
		return new ModelAndView("Error occurred");

	}

}