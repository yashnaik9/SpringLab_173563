package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeService {

	void saveTraniee(Trainee traniee);

	Trainee getTraniee(int id);

	void deleteTraniee(Trainee traniee);

	Iterable<Trainee> getAll();

}
