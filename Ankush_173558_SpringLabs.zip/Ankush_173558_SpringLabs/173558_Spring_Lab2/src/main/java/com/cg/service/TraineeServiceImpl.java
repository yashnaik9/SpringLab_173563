package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeRepo repo;

	@Override
	public void saveTraniee(Trainee traniee) {
		// TODO Auto-generated method stub
		repo.save(traniee);
	}

	@Override
	public Trainee getTraniee(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}

	@Override
	public Iterable<Trainee> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void deleteTraniee(Trainee traniee) {
		// TODO Auto-generated method stub
		repo.delete(traniee);
	}

}
