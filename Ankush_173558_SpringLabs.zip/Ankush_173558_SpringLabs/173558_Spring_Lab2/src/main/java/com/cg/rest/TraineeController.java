package com.cg.rest;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	@Autowired
	private TraineeService service;

	Trainee trainee;
	ArrayList<String> domain;
	ArrayList<String> location;

	@RequestMapping("/")
	public String login(Model model) {
		model.addAttribute("login", new Login());
		return "index";
	}

	@RequestMapping("checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login login, BindingResult result, Model m) {
		if (result.hasErrors()) {
			return "index";
		} else {
			if (login.getUserName().equals("ankush") && login.getPassword() == 12345)
				return "home";
			else {
				m.addAttribute("error", "Invalid Login");
				return "index";
			}
		}
	}

	@RequestMapping("/addtrainee")
	public String addDetail(Model model) {
		model.addAttribute("trainee", new Trainee());
		location = new ArrayList<String>();

		location.add("Mumbai");
		location.add("Bangalore");
		location.add("Chennai");
		location.add("Delhi");

		domain = new ArrayList<String>();

		domain.add("Java");
		domain.add("Selenium");
		domain.add("Spring");
		domain.add("Hibernate");
		domain.add("HTML");
		model.addAttribute("location", location);
		model.addAttribute("domain", domain);
		return "addtrainee";
	}

	@RequestMapping("addtraineedetails")
	public String addTrainee(@ModelAttribute("trainee") @Valid Trainee trainee, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("error", "Enter valid details");
			model.addAttribute("domain", domain);
			model.addAttribute("location", location);
			return "addtraniee";
		} else {
			service.saveTraniee(trainee);
			model.addAttribute("operation", "Trainee added");
			return "home";
		}
	}

	@RequestMapping("deletedtrainee")
	public String deleteTrainee(Model model) {
		System.out.println(trainee);
		if (trainee != null) {
			service.deleteTraniee(trainee);
			trainee = null;
			model.addAttribute("operation", "Trainee deleted");
			return "home";
		} else {
			model.addAttribute("error", "Invalid Id");
			return "deletetrainee";
		}
	}

	@RequestMapping("getdeletetrainee")
	public String getDelTrainee(int id, Model model) {
		trainee = service.getTraniee(id);
		System.out.println(trainee);
		model.addAttribute("traniee", trainee);
		return "deletetrainee";

	}

	@RequestMapping("/deletetrainee")
	public String delete(Model model) {
		model.addAttribute("trainee", null);
		return "deletetrainee";
	}

	@RequestMapping("/get")
	public String getTrainee(Model model) {
		model.addAttribute("trainee", null);
		return "get";
	}

	@RequestMapping("gettrainee")
	public String getTrainee(int id, Model model) {
		Trainee traniee = service.getTraniee(id);
		System.out.println(traniee);
		model.addAttribute("traniee", traniee);
		return "get";

	}

	@RequestMapping("getmodifytraniee")
	public String getModTrainee(int id, Model model) {
		trainee = service.getTraniee(id);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		model.addAttribute("cityList", location);
		model.addAttribute("domain", domain);
		return "modifytrainee";
	}

	@RequestMapping("modifytraineedetails")
	public String modifyTraineeDetails(@ModelAttribute("trainee") Trainee trainee, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("error", "Invalid data");
			model.addAttribute("cityList", location);
			model.addAttribute("domain", domain);
			return "modifytrainee";
		} else {
			service.saveTraniee(trainee);
			model.addAttribute("operation", "Updated");
			return "home";
		}
	}

	@RequestMapping("/modifytrainee")
	public String modifyTrainee(Model model) {
		location = new ArrayList<String>();

		location.add("Chennai");
		location.add("Banglore");
		location.add("Pune");
		location.add("Mumbai");

		domain = new ArrayList<String>();

		domain.add("Java");
		domain.add("Selenium");
		domain.add("Spring");
		domain.add("Hibernate");
		domain.add("HTML");
		model.addAttribute("trainee", new Trainee());
		model.addAttribute("cityList", location);
		model.addAttribute("domain", domain);
		return "modifytrainee";

	}

	@RequestMapping("/alltrainee")
	public String retrieveAllTrainee(Model model) {
		Iterable<Trainee> iterable = service.getAll();
		List<Trainee> list = new ArrayList<>();
		iterable.forEach(list::add);
		for (Trainee trainee : list) {
			System.out.println(trainee);
		}
		model.addAttribute("list", list);
		return "getall";
	}

}
