package com.cg.entity;

import javax.validation.constraints.Size;

public class Login {
	private int password;
	@Size(min = 5, max = 10, message = "Enter Proper username")
	private String userName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

}
