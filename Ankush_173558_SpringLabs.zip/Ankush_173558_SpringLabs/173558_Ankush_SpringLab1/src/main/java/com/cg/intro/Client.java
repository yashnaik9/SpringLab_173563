package com.cg.intro;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.ioc.Employee;
import com.cg.ioc.SBU;

public class Client {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		Employee emp = (Employee) ctx.getBean("employee");
		Scanner scan = new Scanner(System.in);
		SBU sb = (SBU) ctx.getBean("sbu");
		System.out.println("Employee Details" + "\n" + "-----------------------------------------");
		System.out.println(emp);
		System.out.println(sb);
		System.out.println("-----------------------List of employee-----------------------");
		List<Employee> emplist = sb.getEmployeeList();
		for (Employee employee : emplist) {
			System.out.println(employee);
		}
		System.out.println("-------------------------------------------"+"\n"+"Find Employee by Id");
		System.out.println("Enter the employee id:");
		int id=scan.nextInt();
		System.out.println(sb.findEmployee(id));
	}
}
