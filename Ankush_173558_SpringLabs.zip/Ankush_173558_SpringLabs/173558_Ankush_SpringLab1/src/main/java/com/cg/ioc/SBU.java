package com.cg.ioc;

import java.util.List;

import org.springframework.stereotype.Component;

@Component("sbu")
public class SBU {
	private int sbuId;
	private String sbuName;
	private String sbuHead;
	private List<Employee> employeeList;

	public List<Employee> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]";
	}

	public int getSbuId() {
		return sbuId;
	}

	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	public Employee findEmployee(int id) {
		for (Employee employee : employeeList) {
			if (employee.getEmployeId() == id)
				return employee;
		}
		return null;

	}
}
