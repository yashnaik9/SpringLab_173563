import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ioc.Employee;
import com.cg.ioc.SBU;

public class TestEmployee {

	@Test
	public void testGetObject() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		Employee e = (Employee) ctx.getBean("employee");
		assertNotNull("Null Object", e);
		System.out.println("Employee Details"+"\n"+"------------------------------------------------");
		System.out.println("Employee ID: " + e.getEmployeId() + "\n" + "Employee Name: " + e.getEmployeeName() + "\n"
				+ "Employee Salary: " + e.getSalary() + "\n" + "Employee BU: " + e.getBusinessUnit() + "\n"
				+ "Employee Age: " + e.getAge());
		
		SBU sb = (SBU) ctx.getBean("sbu");
		assertNotNull("Null Object", sb);
		System.out.println("\n"+"SBU CODE: " + sb.getSbuId() + "\n" + "SBU Head: " + sb.getSbuHead() + "\n" + "SBU Name: "
				+ sb.getSbuName());

	}
}
