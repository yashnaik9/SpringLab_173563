import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class TestMain {

	@Test
	public void TestEmployee() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		Employee e = (Employee) ctx.getBean(Employee.class);
		System.out.println("Employee Details");
		System.out.println("--------------------");
		System.out.println("Employee Id: "+e.getEmployeeId());
		System.out.println("Employee Name: "+e.getEmployeeName());
		System.out.println("Employee Salary: "+e.getSalary());
		System.out.println("Employee BU: "+e.getBusinessUnit());
		System.out.println("Employee Age: "+e.getAge());
		assertNotNull(e);
	}
}
