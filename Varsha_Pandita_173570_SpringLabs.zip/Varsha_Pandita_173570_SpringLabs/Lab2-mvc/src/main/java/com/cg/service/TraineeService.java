package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeService {

	void addTrainee(Trainee t);

	public String deleteTrainee(Trainee trainee);
	
	Iterable<Trainee> retrieveAll();
	
	Trainee retrievebyId(int id);
	
	public Trainee modifyTrainee(Trainee t, int id);

}
