package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;

import com.cg.repo.ProductRepo;

@RestController
public class ProductController {

	@Autowired
	private ProductRepo repo;

	// Go to product page for adding details
	@GetMapping("/")
	public ModelAndView homePage(Model model) {
		return new ModelAndView("product", "product", new Product());

	}

	// save the prodct details in database
	@PostMapping("/add")
	public Product addProduct(@ModelAttribute("product") Product product, Model model) {
		product = repo.saveProduct(product);
		model.addAttribute("result", "Added Successfully");
		return product;

	}

	// get list of products
	@GetMapping(path = "/products", produces = "application/json")
	public List<Product> showAllProduct() {
		return repo.getAll();
	}

	// exception handling if any any error go to error page
	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })

	public ModelAndView showError(Model model) {
		return new ModelAndView("error");

	}

}