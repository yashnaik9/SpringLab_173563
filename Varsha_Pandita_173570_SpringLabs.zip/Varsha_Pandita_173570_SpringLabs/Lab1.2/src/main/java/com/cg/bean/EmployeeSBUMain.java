package com.cg.bean;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeSBUMain {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employeeSBU.xml");
		Employee e = (Employee) ctx.getBean(Employee.class);
		SBU s = (SBU) ctx.getBean(SBU.class);
		System.out.println("Employee Details");
		System.out.println("--------------------");
		
		System.out.println(e +" \n" );
	}

}
