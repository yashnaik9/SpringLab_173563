package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;

public class EmpMain {

	public static void main(String[] args) {

		
ApplicationContext ctx = new ClassPathXmlApplicationContext("employee1.xml");
		
		Employee e1 = (Employee) ctx.getBean("employeebean");
		
		
		
		
		System.out.println("-----Employee and Sbu details----");
		
		System.out.println(e1);
		
		
		
	}

}
