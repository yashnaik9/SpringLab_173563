package com.cg.bean;

public class Sbu {

	private int sbuId;
	private String sbuName;
	private String sbuHead;
	
	
	
	public Sbu() {
	}



	public Sbu(int sbuId, String sbuName, String sbuHead) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}



	@Override
	public String toString() {
		return "Sbu [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]";
	}
	
	
	
}
