package com.cg.bean;

public class Employee {
	
	private int employeeId;
	private String employeeName;
	private double salary;
	private String businessUnit;
	private int age;

	public Employee() {
	}
	
	private Sbu sbu;

	public Sbu getSbu() {
		return sbu;
	}

	public void setSbu(Sbu sbu) {
		this.sbu = sbu;
	}

	public Employee(int employeeId, String employeeName, double salary, String businessUnit, int age,Sbu sbu) {
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.businessUnit = businessUnit;
		this.age = age;
		this.sbu=sbu;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
				+ ", businessUnit=" + businessUnit + ", age=" + age + "]"+sbu;
	}

}
