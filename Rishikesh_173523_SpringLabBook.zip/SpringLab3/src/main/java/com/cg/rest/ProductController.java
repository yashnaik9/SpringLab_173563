package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.NestedServletException;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
public class ProductController {

	@Autowired
	private ProductRepo repo;
	
	
	@GetMapping("/addproduct")
	public ModelAndView sayHello(Model model) {
		return new ModelAndView("product","productdetails", new Product());
	}
	
	@PostMapping("addproduct")
	public ModelAndView addProduct(@ModelAttribute("productdetails") Product prod, Model model) {
		
		repo.saveProduct(prod);

		return new ModelAndView("productadded","productdetails", new Product());

	}
	

	@GetMapping(path="/products", produces="application/json")
			public List<Product> getAllProducts(){
		return repo.getAll();
	}
	
	@ExceptionHandler({java.sql.SQLIntegrityConstraintViolationException.class,
		NestedServletException.class,
		JpaSystemException.class,
		javax.persistence.PersistenceException.class,
		org.hibernate.exception.ConstraintViolationException.class
	})
	public ModelAndView error() {
		return new ModelAndView("errorpage");
	}
}
