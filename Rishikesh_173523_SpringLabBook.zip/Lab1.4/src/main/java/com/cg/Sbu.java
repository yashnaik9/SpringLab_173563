package com.cg;

import java.util.ArrayList;
import java.util.List;

public class Sbu {

	
	private  int sbuCode;
	private String sbuName;
	private String sbuHead;
	
	List<Employee> empList= new ArrayList<Employee>();

	public List<Employee> getEmpList() {
		return empList;
	}

	public Sbu(int sbuCode, String sbuName, String sbuHead, List<Employee> empList) {
		this.sbuCode = sbuCode;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.empList = empList;
	}

	@Override
	public String toString() {
		return "Sbu [sbuCode=" + sbuCode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + " \nEmployee details=" + empList
				+ "]";
	}
	
	public void addEmp(Employee employee) {
		empList.add(employee);
	}
	
	public Employee findEmp(int id) {
		for (Employee employee : empList) {
			if(employee.getEmpId()==id)
				return employee;
		}
		return null;
	}
}
