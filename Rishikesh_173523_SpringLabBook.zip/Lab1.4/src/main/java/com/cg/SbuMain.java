package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SbuMain {

	public static void main(String[] args) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("empsbu.xml");
		Sbu s1 = (Sbu) ctx.getBean("sbubean");

		System.out.println("-----Sbu through list----");

		Employee e1 = new Employee(101, "Rishi", 20000.00);
		s1.addEmp(e1);

		System.out.println(s1.findEmp(101));

	}

}
