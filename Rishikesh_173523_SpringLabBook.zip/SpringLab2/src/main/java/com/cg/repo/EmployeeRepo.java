package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.TraineeDetails;

public interface EmployeeRepo extends CrudRepository<TraineeDetails, Integer> {

}
