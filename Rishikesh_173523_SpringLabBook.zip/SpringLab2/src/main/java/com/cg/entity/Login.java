package com.cg.entity;

import javax.persistence.Id;


public class Login {

	@Id
	String userName;
	String password;
	public String getUsername() {
		return userName;
	}
	public void setUsername(String username) {
		this.userName = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
