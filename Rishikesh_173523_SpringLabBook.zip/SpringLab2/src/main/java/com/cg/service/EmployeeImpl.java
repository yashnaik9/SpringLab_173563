package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.TraineeDetails;
import com.cg.repo.EmployeeRepo;

@Repository
@Transactional
public class EmployeeImpl implements IEmployee {

	@Autowired
	private EmployeeRepo repo;

	@Override
	public void saveTrainee(TraineeDetails details) {
		repo.save(details);
	}

	@Override
	public TraineeDetails getId(int tid) {
		return repo.findById(tid).get();
	}

	@Override
	public String deleteTrainee(TraineeDetails trainee) {
		 
		 repo.delete(trainee);
		 return "Record Deleted";
		
	}

	@Override
	public List<TraineeDetails> getAll() {
		 return (List<TraineeDetails>) repo.findAll();
	}

}
