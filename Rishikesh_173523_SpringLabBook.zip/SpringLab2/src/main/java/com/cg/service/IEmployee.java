package com.cg.service;

import java.util.List;

import com.cg.entity.TraineeDetails;

public interface IEmployee {

	
	 void saveTrainee(TraineeDetails details);
	 
	 TraineeDetails getId(int tid);
	 
	 public String deleteTrainee(TraineeDetails trainee);
	 
	 List<TraineeDetails> getAll();
}
