package com.cg.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Login;
import com.cg.entity.TraineeDetails;
import com.cg.service.EmployeeImpl;

@Controller
public class LoginController {

	@Autowired
	private EmployeeImpl service;

	@RequestMapping("/")
	public String greeting() {
		// m.addAttribute("login", login);

		return "login";
	}

	@RequestMapping("gotomain")
	public String goToMain() {
		return "success";
	}

	@RequestMapping("loginsuccess")
	public String Login(@RequestParam("name") String n, @RequestParam("pwd") String pass, Model m) {

		String invalid = "enter valid login details";

		if (n.equals("rishi") && pass.equals("admin")) {
			m.addAttribute("uname", n);

			return "success";
		} else {

			m.addAttribute("invalid", invalid);
			return "login";
		}

	}

	@RequestMapping("addform")
	public String AddEmpForm(Model model) {
		model.addAttribute("traineedetails", new TraineeDetails());

		return "addempform";
	}

	@RequestMapping("addtrainee")
	public String addTrainee(@ModelAttribute("traineedetails") TraineeDetails details, Model model) {
		model.addAttribute("traineedetails", new TraineeDetails());
		service.saveTrainee(details);

		return "traineeadded";

	}

	@RequestMapping("delemp")
	public String delTrainee(Model model) {
		model.addAttribute("traineedetails", new TraineeDetails());
		return "deleteform";
	}

	@RequestMapping("/search")
	public String searchTrainee(Model model, int tid) {
		TraineeDetails trainee = service.getId(tid);
		System.out.println(trainee);
		model.addAttribute("deletetrainee", trainee);
		return "deleteform";
	}

	@RequestMapping("/delete")
	public String deleteTrainee(Model model) {
		model.addAttribute("deletetrainee");
		return "deleteform";
	}

	@RequestMapping("deletetrainee")
	public String deleteTrainee(@ModelAttribute("deletetrainee") TraineeDetails trainee, Model model) {
		service.deleteTrainee(trainee);
		return "success";
	}

	@RequestMapping("retreiveemp")
	public String retTrainee(Model model) {
		model.addAttribute("traineedetails", new TraineeDetails());
		return "findform";
	}

	@RequestMapping("/find")
	public String findTrainee(Model model, int tid) {
		TraineeDetails trainee = service.getId(tid);
		System.out.println(trainee);
		model.addAttribute("findtrainee", trainee);
		return "findform";
	}

	@RequestMapping("/findemp")
	public String findTrainee(Model model) {
		model.addAttribute("findtrainee");
		return "findform";
	}

	
	
	
		
	
	
}
