package com.cg.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.TraineeDetails;
import com.cg.service.EmployeeImpl;

@Controller
public class RetrieveController {

	
	@Autowired
	private EmployeeImpl service;
	
	
	@RequestMapping("retallemp")
	public String allEmpForm(Model model) {
		model.addAttribute("traineedetails", new TraineeDetails());
		return "allemp";
	}
	
	@RequestMapping("modemp")
	public String AddEmpForm(Model model) {
		model.addAttribute("traineedetails", new TraineeDetails());

		return "updateemp";
	}
	
	
	@RequestMapping(value="modify")
	public String update(Model model, int tid,TraineeDetails trainee) {
		
		 trainee=service.getId(tid);
		model.addAttribute("traineedetails", trainee);
		
		return "updateemp";
	}
	
	@RequestMapping(value="modifyTrainee")
	public String updateTrainee(@ModelAttribute("traineedetails") TraineeDetails trainee, Model model) {
		service.saveTrainee(trainee);
		return "updatedone";
	}
	
}
