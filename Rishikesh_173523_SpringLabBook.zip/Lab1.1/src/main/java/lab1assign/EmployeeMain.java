package lab1assign;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeMain {

	public static void main(String[] args) {

		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		
		Employee e1 = (Employee) ctx.getBean("employeebean");
		
		System.out.println("-----Employee details----");
		
		System.out.println(e1);
		
	}

}
